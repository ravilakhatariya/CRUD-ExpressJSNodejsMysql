const express = require('express');
const router = express.Router();
const usersController = require('../controllers/usersController');


router.get('/', usersController.view);
router.post('/adduser', usersController.create);
router.get('/adduser', usersController.createform);
router.get('/:id',usersController.delete);
router.get('/edituser/:id', usersController.edit);
router.post('/edituser/:id', usersController.update);

// router.get('/loginform', usersController.loginform);





module.exports = router;//router ne connection mate