var express = require('express');
var router = express.Router();
var db=require('../database');
/* GET users listing. */
router.get('/login', function(req, res, next) {
  res.render('login');
});
router.post('/login', function(req, res){
    var Name = req.body.Name;
    var MobileNo = req.body.MobileNo;
    var sql='SELECT * FROM user WHERE Name =? AND MobileNo =?';
    db.query(sql, [Name, MobileNo], function (err, data, fields) {
        if(err) throw err
        if(data.length>0){
            req.session.loggedinUser= true;
            req.session.Name= Name;
            res.redirect('/');
        }else{
            res.render('login',{alertMsg:"Your MobileNo Address or MobileNo is wrong"});
        }
    })
})
module.exports = router;

